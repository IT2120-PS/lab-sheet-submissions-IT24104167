
setwd('C:/Users/it24104167/Downloads/IT24104167')

#Import data set
branch_data <- read.csv("Exercise.txt", header = TRUE)

#view the file in separate window
fix(data)

head(branch_data)
str(branch_data)

#Q3
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue",
        border = "black")
#Q4
fivenum(branch_data$Advertising)

#Q5
IQR(branch_data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  outliers <- x[x < (Q1 - 1.5*IQR_val) | x > (Q3 + 1.5*IQR_val)]
  return(outliers)
}

# Check outliers in Years variable
find_outliers(branch_data$Years)

